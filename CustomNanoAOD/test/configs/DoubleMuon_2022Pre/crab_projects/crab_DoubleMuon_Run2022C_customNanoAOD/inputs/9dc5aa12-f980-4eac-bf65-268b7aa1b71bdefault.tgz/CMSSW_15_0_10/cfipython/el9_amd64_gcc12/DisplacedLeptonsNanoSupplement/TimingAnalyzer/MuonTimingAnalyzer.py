import FWCore.ParameterSet.Config as cms

def MuonTimingAnalyzer(*args, **kwargs):
  mod = cms.EDAnalyzer('MuonTimingAnalyzer',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
