import FWCore.ParameterSet.Config as cms

def OverlapAnalyzer(*args, **kwargs):
  mod = cms.EDAnalyzer('OverlapAnalyzer',
    promptSource = cms.InputTag('slimmedMuons'),
    displacedSource = cms.InputTag('slimmedDisplacedMuons'),
    min_dR = cms.double(0.01),
    min_dPtRelative = cms.double(0.1),
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
