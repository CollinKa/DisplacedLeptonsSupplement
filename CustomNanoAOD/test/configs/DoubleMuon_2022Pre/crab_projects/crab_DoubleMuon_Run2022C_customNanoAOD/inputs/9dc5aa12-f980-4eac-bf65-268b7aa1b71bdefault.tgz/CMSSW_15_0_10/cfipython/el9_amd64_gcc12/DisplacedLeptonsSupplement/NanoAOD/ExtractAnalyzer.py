import FWCore.ParameterSet.Config as cms

def ExtractAnalyzer(*args, **kwargs):
  mod = cms.EDAnalyzer('ExtractAnalyzer',
    src = cms.InputTag('slimmedDisplacedMuons'),
    ptCut = cms.double(15),
    variables = cms.PSet(),
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
